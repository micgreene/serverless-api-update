'use strict';

const peopleModel = require('./schema.js');

exports.handler = async (event) => {
  try {
    const body = JSON.parse(event.body);

    let foundRecord;

    
    const id = event.queryStringParameters && event.queryStringParameters.id;
    const { name, phone } = body;

    const sendData = {
      id: id,
      name: body.name,
      phone: body.phone
    }

    const list = await peopleModel.query('id').eq(id).exec();
    foundRecord = list[0];

    const data = await peopleModel.update(sendData);

    return {
      statuscode: 201,
      body: JSON.stringify(data)
    }

  } catch (e) {
    return {
      statuscode: 500,
      body: e.message
    }

  }
  return {
    statuscode: 201,
    body: 'Saved New Individual to Database'
  }
};